
# Snapshot Example<!--!{#example_snapshot}-->

This example asks the camera to take a picture and then retrieves the data and writes it to an SD card.
