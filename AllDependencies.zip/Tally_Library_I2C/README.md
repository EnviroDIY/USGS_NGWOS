# Tally_Library
An Arduino library for interfacing to the Project Tally Event counter 
