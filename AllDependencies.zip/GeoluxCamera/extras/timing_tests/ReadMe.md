# Timing Tests<!--!{#extra_timing_tests}-->

This is a series of timing tests for the Geolux Hydrocam.
