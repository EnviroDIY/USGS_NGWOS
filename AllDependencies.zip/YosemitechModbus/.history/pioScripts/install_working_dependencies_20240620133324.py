# %%
import subprocess
from os import makedirs
from os.path import isdir
import re
import configparser
import json

shared_lib_dir = "C:\\Users\\sdamiano\\Documents\\GitHub\\EnviroDIY\\YosemitechModbus\\.pio\\libdeps\\shared"
shared_lib_abbr = ".pio/libdeps/shared"
ini_file = (
    "C:\\Users\\sdamiano\\Documents\\GitHub\\EnviroDIY\\YosemitechModbus\\platformio.ini"
)
json_file = (
    "C:\\Users\\sdamiano\\Documents\\GitHub\\EnviroDIY\\YosemitechModbus\\library.json"
)

from platformio.package.manifest.parser import ManifestParserFactory
from platformio.package.manifest.schema import ManifestSchema
from platformio.project.config import ProjectConfig

mp = ManifestParserFactory.new_from_file(json_file)
lib_manifest = ManifestSchema().load_manifest(mp.as_dict())
proj_config = ProjectConfig(path=ini_file)
envs = proj_config.envs()

# %%
print(f"\nInstalling and updating common libraries in {shared_lib_dir}")

# Create shared_lib_dir if it does not exist
if not isdir(shared_lib_dir):
    makedirs(shared_lib_dir)


def get_shared_lib_deps(include_version: bool = True, verbose: bool = False):
    if verbose:
        print(f"\nDependencies listed in {json_file}")
    lib_deps = []
    parsed_deps = lib_manifest.get("dependencies")
    for lib in parsed_deps:
        if "owner" in lib.keys() and "name" in lib.keys() and "version" in lib.keys():
            lib_dep = f"{lib['owner']}/{lib['name']}"
            if include_version:
                lib_dep += f"@{lib['version']}"
            lib_deps.append(lib_dep)
            if verbose:
                print(lib_dep)
        elif "name" in lib.keys() and "version" in lib.keys():
            lib_dep = f"{lib['name']}"
            if include_version:
                lib_dep += f"@{lib['version']}"
            lib_deps.append(lib_dep)
            if verbose:
                print(lib_dep)
        else:
            if verbose:
                print("**************")
                print(lib)
    lib_deps.append("vshymanskyy/StreamDebugger")
    lib_deps.append("AltSoftSerial=https://github.com/PaulStoffregen/AltSoftSerial.git")
    lib_deps.append("SoftwareWire=https://github.com/Testato/SoftwareWire.git#v1.5.1")
    lib_deps.append("NeoSWSerial=https://github.com/SRGDamia1/NeoSWSerial.git")
    lib_deps.append(
        "SoftwareSerial_ExternalInts=https://github.com/EnviroDIY/SoftwareSerial_ExternalInts.git"
    )
    return lib_deps


deps_to_install = get_shared_lib_deps(True, True)
deps_to_update = get_shared_lib_deps(False, False)


def get_ignored_lib_deps(env):
    return proj_config.get(section=f"env:{env}", option="lib_ignore")


pio_pkg_command = ["platformio", "pkg"]


# %%
def install_shared_dependencies(verbose):
    if verbose:
        print("\nInstalling libraries")

    # Build dependency installation command
    install_cmd = pio_pkg_command + ["install", "-g"]
    install_cmd.extend(["--storage-dir", shared_lib_dir])

    # # Add verbose to command
    # if int(verbose) < 1:
    #     install_cmd.append("-s")

    # Add dependencies to command
    for lib in deps_to_install:
        lib_install_cmd = install_cmd.copy()
        lib_install_cmd.append("-l")
        lib_install_cmd.append(lib)

        # Run command
        # print(lib_install_cmd)
        if verbose:
            print(f"Installing {lib}")
        install_result = subprocess.run(
            lib_install_cmd, capture_output=True, text=True, check=True
        )
        print(install_result.stdout)
        # print(install_result.stderr)


install_shared_dependencies(True)


# %%
def update_shared_dependencies(verbose):
    if verbose:
        print("\nUpdating libraries")
    # Build dependency update command
    update_cmd = pio_pkg_command + ["update", "-g"]

    # Add verbose to command
    if int(verbose) < 1:
        update_cmd.append("-s")

    # set the storage directory for the libraries
    update_cmd.extend(["--storage-dir", shared_lib_dir])

    # Add dependencies to command
    for lib in deps_to_update:
        lib_update_cmd = update_cmd.copy()
        lib_update_cmd.append("-l")
        lib_update_cmd.append(lib)

        # Run update command
        # print(lib_update_cmd)
        if verbose:
            print(f"Updating {lib}")
        update_result = subprocess.run(
            lib_update_cmd, capture_output=True, text=True, check=True
        )
        print(update_result.stdout)
        # print(update_result.stderr)


update_shared_dependencies(True)


# %%
def parse_global_installs(verbose: bool = False):
    # Build dependency list command
    # pio pkg list -v -g  --only-libraries  --storage-dir "C:\Users\sdamiano\Documents\GitHub\EnviroDIY\ModularSensors\.pio\libdeps\shared"
    list_cmd = pio_pkg_command + ["list", "-g", "--only-libraries", "-v"]

    # set the storage directory for the libraries
    list_cmd.extend(["--storage-dir", shared_lib_dir])

    # Run update command
    print("Listing libraries")
    # print(list_cmd)
    list_result = subprocess.run(list_cmd, capture_output=True, text=True, check=True)
    # print(list_result.stdout)
    # print(list_result.stderr)

    lib_list_presort = []

    for line in list_result.stdout.split("\n"):
        if int(verbose) >= 1:
            print(line)
        # print(line.split())
        match = re.search(
            r".*? (?P<lib_name>[\w\s-]*?) @ (?P<lib_version>[\w\s\.\+-]*?) \(required: (?:git\+)?(?P<lib_req>.*?)(?: @ .*?)?, (?P<lib_dir>.*?)\)",
            line,
        )
        if match:
            if int(verbose) >= 1:
                print("Library name: {}".format(match.group("lib_name")))
                print("Library Version: {}".format(match.group("lib_version")))
                print("Library Req: {}".format(match.group("lib_req")))
                print("Library Storage Dir: {}".format(match.group("lib_dir")))
            shared_entry = list(
                filter(
                    lambda x: match.group("lib_req").lower() in x.lower(),
                    deps_to_install,
                )
            )
            is_in_shared = len(shared_entry) > 0
            if is_in_shared:
                shared_position = deps_to_install.index(shared_entry[0])
            else:
                shared_position = -1
            if match.group("lib_name") == "Adafruit BusIO":
                shared_position = -2
            match_groups = match.groupdict()
            match_groups["shared_entry"] = shared_entry
            match_groups["is_in_shared"] = is_in_shared
            match_groups["shared_position"] = shared_position
            lib_list_presort.append(match_groups)
        else:
            if int(verbose) >= 1:
                print("XXXXXXXXXXXXXXXXXXXXXXX NO MATCH XXXXXXXXXXXXXXXXXXXXXXX")
        if int(verbose) >= 1:
            print("##########")

    lib_list = sorted(lib_list_presort, key=lambda d: d["shared_position"])
    if int(verbose) >= 1:
        print(lib_list)
    return lib_list


lib_list = parse_global_installs(False)


# %%
def create_symlink_list(environment: str, verbose: bool = False):
    lib_symlinks = []
    ign_symlinks = []
    for lib in lib_list:
        is_ignored = lib["lib_name"] in get_ignored_lib_deps(environment)
        if not is_ignored or lib["lib_name"] in [
            "Adafruit GFX Library",
            "Adafruit SSD1306",
        ]:
            lib_symlinks.append(
                f"{lib['lib_name']}=symlink://{lib['lib_dir']}".replace(
                    shared_lib_dir, shared_lib_abbr
                )
                .replace("\\\\", "/")
                .replace("\\", "/")
            )
        else:
            ign_symlinks.append(
                f"{lib['lib_name']}=symlink://{lib['lib_dir']}".replace(
                    shared_lib_dir, shared_lib_abbr
                )
                .replace("\\\\", "/")
                .replace("\\", "/")
            )
    if int(verbose) >= 1:
        print(lib_symlinks)

    return lib_symlinks


common_lib_symlinks = create_symlink_list("env", False)
for item in common_lib_symlinks:
    print("   ", item)
# for env in envs:
#     env_symlinks = create_symlink_list(env, False)

# %%
