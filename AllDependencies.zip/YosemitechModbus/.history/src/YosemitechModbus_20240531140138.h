/**
 * @file YosemitechModbus.h
 * @copyright Stroud Water Research Center
 * Part of the EnviroDIY YosemitechModbus library for Arduino.
 * This library is published under the BSD-3 license.
 * @author Sara Geleskie Damiano <sdamiano@stroudcenter.org>
 *
 * @brief Contains the YosemitechModbus class declarations.
 */

#ifndef YosemitechModbus_h
#define YosemitechModbus_h

#include <Arduino.h>
#include <SensorModbusMaster.h>

/**
 * @brief The various Yosemitech sensors.
 */
typedef enum yosemitechModel {
    Y502 = 0,  ///< [Online Optical Dissolved Oxygen
               ///< Sensor](http://en.yosemitech.com/aspcms/product/2020-5-8/72.html)
    Y504,      ///< [Optical Dissolved Oxygen
               ///< Sensor](http://en.yosemitech.com/aspcms/product/2021-3-1/161.html)

    // Y505,  ///< [Aquaculture Optical Dissolved Oxygen
    // (ODO)](http://en.yosemitech.com/aspcms/product/2020-5-8/79.html)

    Y510,  ///< [Turbidity
           ///< Sensor](http://en.yosemitech.com/aspcms/product/2020-5-8/76.html)
    Y511,  ///<  [Turbidity Sensor with
           ///<  wiper](http://en.yosemitech.com/aspcms/product/2020-5-8/76.html)
    Y513,  ///<  [Blue Green Algae sensor with
           ///<  Wiper](http://en.yosemitech.com/aspcms/product/2020-5-8/82.html)
    Y514,  ///<  [Chlorophyll Sensor with
           ///<  Wiper](http://en.yosemitech.com/aspcms/product/2020-4-23/39.html)
    Y516,  ///< [Oil in water (Crude
           ///< Oil)](http://en.yosemitech.com/aspcms/product/2020-5-8/69.html)

    // Y517,    ///< [Oil in water (Refined
    // Oil)](http://en.yosemitech.com/aspcms/product/2020-5-8/69.html)

    Y520,  ///<  [4-Electrode Conductivity
           ///<  Sensor](http://en.yosemitech.com/aspcms/product/2020-4-23/58.html)

    // Y521,    ///<  [4-Electrode Conductivity Sensor(metal
    // housing)](http://en.yosemitech.com/aspcms/product/2020-4-23/58.html)

    Y532,   ///<  [pH](http://en.yosemitech.com/aspcms/product/2020-6-15/154.html)
    Y533,   ///<  [ORP](http://en.yosemitech.com/aspcms/product/2020-5-8/91.html)
    Y550,   ///<  [UV254/COD Sensor, old version no longer
            ///<  sold](http://en.yosemitech.com/aspcms/product/2020-5-8/94.html)
    Y551,   ///<  [UV254/COD
            ///<  Sensor](http://en.yosemitech.com/aspcms/product/2020-5-8/94.html)
    Y560,   ///<  [NH4 Probe](http://en.yosemitech.com/aspcms/product/2020-4-23/61.html)
    Y700,   ///<  Water Pressure/Depth Sensor Prototype developed for Clean Water
            ///<  Services
    Y4000,  ///<  [Multiparameter
            ///<  Sonde](http://en.yosemitech.com/aspcms/product/2020-5-8/95.html)
    UNKNOWN  ///<  Use if the sensor model is unknown. Doing this is generally a bad
             ///<  idea, but it can be helpful for doing things like getting the serial
             ///<  number of an unknown model.
} yosemitechModel;

class yosemitech {

 public:

    /**
     * @brief This function sets up the communication.
     *
     * It should be run during the arduino "setup" function.
     * The "stream" device must be initialized prior to running this.
     *
     * @param model The model of the Yosemitech sensor, from #yosemitechModel
     * @param modbusSlaveID The byte identifier of the modbus slave device.
     * @param stream A pointer to the Arduino stream object to communicate with.
     * @param enablePin A pin on the Arduino processor to use to send an enable signal
     * to an RS485 to TTL adapter. Use a negative number if this does not apply.
     * Optional with a default value of -1.
     * @return True if the starting communication was successful, false if not.
     */
    bool begin(yosemitechModel model, byte modbusSlaveID, Stream* stream,
               int enablePin = -1);
    /**
     * @brief This function sets up the communication.
     *
     * It should be run during the arduino "setup" function.
     * The "stream" device must be initialized prior to running this.
     *
     * @param model The model of the Yosemitech sensor, from #yosemitechModel
     * @param modbusSlaveID The byte identifier of the modbus slave device.
     * @param stream A reference to the Arduino stream object to communicate with.
     * @param enablePin A pin on the Arduino processor to use to send an enable signal
     * to an RS485 to TTL adapter. Use a negative number if this does not apply.
     * Optional with a default value of -1.
     * @return True if the starting communication was successful, false if not.
     */
    bool begin(yosemitechModel model, byte modbusSlaveID, Stream& stream,
               int enablePin = -1);

    /**
     * @brief Returns a pretty string with the model information
     *
     * @note This is only based on the model input from the "begin" fxn.
     * The sensor itself does not return its model information.
     *
     * @return *String* The Yosemitech sensor model
     */
    String getModel(void);

    /**
     * @brief Returns a pretty string with the parameter measured.
     *
     * @note This is only based on the model input from the "begin" fxn.
     * The sensor itself does not return this information.
     *
     * @return *String* The primary parameter being measured on this Yosemitech sensor
     * model.
     */
    String getParameter(void);

    /**
     * @brief Returns a pretty string with the measurement units.
     *
     * @note This is only based on the model input from the "begin" fxn.
     * The sensor itself does not return this information.
     *
     * @return *String* The units of primary parameter being measured on this Yosemitech
     * sensor model.
     */
    String getUnits(void);

    /**
     * @brief Gets the modbus slave ID.
     *
     * Not supported by many sensors.
     *
     * @return *byte* The slave ID of the Yosemitech sensor
     */
    byte getSlaveID(void);

    /**
     * @brief Sets a new modbus slave ID
     *
     * @param newSlaveID The new slave ID for the Yosemitech sensor
     * @return True if the slave ID was successfully set, false if not.
     */
    bool setSlaveID(byte newSlaveID);

    /**
     * @brief Gets the instrument serial number as a String
     *
     * @return *String* The serial number of the Yosemitech sensor
     */
    String getSerialNumber(void);

    /**
     * @brief Gets the hardware and software version of the sensor
     *
     * The float variables for the hardware and software versions must be initialized
     * prior to calling this function.
     *
     * The reference (&) is needed when declaring this function so that the function is
     * able to modify the actual input floats rather than create and destroy copies of
     * them.
     *
     * There is no need to add the & when actually using the function.
     *
     * @param hardwareVersion A reference to a float object to be modified with the
     * hardware version.
     * @param softwareVersionA reference to a float object to be modified with the
     * software version.
     * @return True if the hardware and software versions were successfully updated,
     * false if not.
     */
    bool getVersion(float& hardwareVersion, float& softwareVersion);

    /**
     * @brief Tells the optical sensors to begin taking measurements
     */
    bool startMeasurement(void);

    /**
     * @brief Tells the optical sensors to stop taking measurements
     */
    bool stopMeasurement(void);

    /**
     * @brief Gets values back from the sensor
     * The float variables for value1 and value2 and the byte for the error
     * code must be initialized prior to calling this function.
     * This function is overloaded so you have the option of getting:
     * 1 value - This will be only the parameter value
     * 1 value and an error code - Parameter value and the error code
     * 2 values - This will be the parameter and the temperature,
     *            with the parameter first and the temperature second
     * 2 values and an error code - As two values, but with error code
     * 3 values - The parameter, the temperature, and a third value for the
     *            sensors that return can return something else
     *            -- Y532 (pH) can return electrical potential
     *            -- Y551 (COD) can return turbidity
     *            -- Y560 (Ammonium) returns NH4_N (mg/L) and pH as primary parameters,
     *            but can return more.
     *            -- Y504 (DO) allows calculation of DO in mg/L, which can be returned
     * 3 values and an error code - As three values, but with error code
     *
     * @note The one, two, and three value variants will simply return false for a sonde
     */
    bool getValues(float& parmValue);
    bool getValues(float& parmValue, byte& errorCode);
    bool getValues(float& parmValue, float& tempValue);
    bool getValues(float& parmValue, float& tempValue, byte& errorCode);
    bool getValues(float& parmValue, float& tempValue, float& thirdValue);
    bool getValues(float& parmValue, float& tempValue, float& thirdValue,
                   byte& errorCode);
    /**
     * @brief Gets values back from the sensor
     * 8 values - For sondes Y4000 and Y560.
     *          - Y4000 Sonde returns in this order: "DO; Turb; Cond; pH; Temp; ORP;
     *          Chl; BGA"
     *          - Y560 Ammonium returns these groupings of parameters:
     *                 - pH, pH_potential (mV)
     *                 - NH4+_potential (mV), K_potential (mV)
     *                 - NH4_N, NH4+, K+ (all in mg/L)
     *                 - Temperature (C)
     * 8 values and an error code - As 8 values, but with error code
     * @note The 8 value versions will return false for anything but a sonde
     */
    bool getValues(float& firstValue, float& secondValue, float& thirdValue,
                   float& forthValue, float& fifthValue, float& sixthValue,
                   float& seventhValue, float& eighthValue);  // For Y4000 Sonde
    bool getValues(float& firstValue, float& secondValue, float& thirdValue,
                   float& forthValue, float& fifthValue, float& sixthValue,
                   float& seventhValue, float& eighthValue, byte& errorCode);
    /**
     * @brief Gets the main "parameter" value as a float
     *
     * This is overloaded, so you have the option of getting the error code in another
     * pre-initialized variable, if you want it and the sensor supports it.
     */
    float getValue(void);
    float getValue(byte& errorCode);

    /**
     * @brief Returns the temperatures value from a sensor as a float
     */
    float getTemperatureValue(void);

    /**
     * @brief Returns raw electrical potential value from the sensor as a float
     *
     * This only applies to pH
     */
    float getPotentialValue(void);

    /**
     * @brief Returns DO in mg/L (instead of % saturation) as a float
     *
     * This only applies to DO and is calculated in the getValues() equation using the
     * measured temperature and a salinity of 0 and pressure of 760 mmHg (sea level)
     */
    float getDOmgLValue(void);

    /**
     * @brief Gets the calibration constants for the sensor
     *
     * The float variables must be initialized prior to calling this function.
     * MOST sensors have two calibration coefficients:  K = slope, B = intercept
     * The calibration is applied to all values returned by the sensor as:
     *    value_returned = (value_raw * K) + B
        bool getCalibration(float& K, float& B);
     * The pH sensor uses SIX calibration coefficients
     * Factory calibration values for pH are:  K1=6.86, K2=-6.72, K3=0.04, K4=6.86,
     * K5=-6.56, K6=-1.04
     */
    bool getCalibration(float& K1, float& K2, float& K3, float& K4, float& K5,
                        float& K6);

    /**
     * @brief Sets the calibration constants for a sensor
     *
     * The suggested calibration protocol for sensors with a 2-coefficient calibration
     * is:
     *    1.  Use this command to set calibration coefficients as K = 1 and B = 0
     *    2.  Put the probe in a solution of known value.
     *    3.  Send the "startMeasurement" command and allow the probe to stabilize.
     *    4.  Send the "getValue" command to get the returned parameter value.
     *        (Depending on the sensor, you may want to take multiple values and average
     *        them.)
     *    5.  Ideally, repeat steps 2-4 in multiple standard solutions
     *    6.  Calculate the slope (K) and offset (B) between the known values for the
     *    standard
     *        solutions and the values returned by the sensor.
     *        (x - values from sensor, y = values of standard solutions)
     *    7.  Send the calculated slope (K) and offset (B) to the sensor using
     *        this command.
     *
     * The pH sensor can be calibrated in this fashion, or it can be calibrated
     * using the steps detailed below for the functions pHCalibrationPoint and
     * pHCalibrationStatus.
     */
    bool setCalibration(float K, float B);

    /**
     * @brief Sets the FULL calibration constants for a pH sensor, which requires 6
     * coefficients.
     *
     * Factory calibration values for pH are:  K1=6.86, K2=-6.72, K3=0.04, K4=6.86,
     * K5=-6.56, K6=-1.04. Use the functions pHCalibrationPoint and pHCalibrationStatus
     * to calibrate and verify calibrations of these meters
     */
    bool setCalibration(float K1, float K2, float K3, float K4, float K5, float K6);

    /**
     * @brief Sets the 3 calibration points for a pH sensor
     *
     * Calibration steps for pH (3 point calibration only):
     *   1. Put sensor in solution and allow to stabilize for 1 minute
     *   2. Input value of calibration standard (ie, run command pHCalibrationPoint(pH))
     *   3. Repeat for points 2 and 3 (pH of 4.00, 6.86, and 9.18 recommended)
     *   4. Read calibration status
     */
    bool pHCalibrationPoint(float pH);

    /**
     * @brief Verifies the success of a calibration for a pH sensor
     *
     * Return values:
     *   0x00 - Success
     *   0x01 - Non-matching calibration standards
     *   0x02 - Less than 3 points used in calibration
     *   0x04 - Calibration coefficients out of range
     */
    byte pHCalibrationStatus(void);

    /**
     * @brief Sets the cap coefficients constants for a sensor
     *
     * This only applies to dissolved oxygen sensors.
     * The sensor caps should be replaced yearly or as the readings beome unstable.
     * The values of these coefficients are supplied by the manufacturer.
     */
    bool setCapCoefficients(float K0, float K1, float K2, float K3, float K4, float K5,
                            float K6, float K7);
    /**
     * @brief Immediately activates the cleaning brush for sensors with one.
     *
     * @note The brush also activates as soon as power is applied.
     * @note One cleaning sweep with the brush takes about 10 seconds.
     * @note Brushing commands will only work on turbidity sensors with
     * hardware Rev1.0 and software Rev1.7 or later
     */
    bool activateBrush(void);

    /**
     * @brief Sets the brush interval - that is, how frequently the brush will run if
     * power is continuously applied to the sensor.
     *
     * @note Brushing commands will only work on turbidity sensors with hardware Rev1.0
     * and software Rev1.7 or later
     */
    bool setBrushInterval(uint16_t intervalMinutes);

    /**
     * @brief Returns the brushing interval - that is, how frequently the brush will run
     * if power is continuously applied to the sensor.
     *
     * @note Brushing commands will only work on turbidity sensors with hardware Rev1.0
     * and software Rev1.7 or later
     */
    uint16_t getBrushInterval(void);

    /**
     * @brief Sets a stream for debugging information to go to;
     */
    void setDebugStream(Stream* stream) {
        modbus.setDebugStream(stream);
    }
    void stopDebugging(void) {
        modbus.stopDebugging();
    }


 private:
    int _model;  // The sensor model

    byte         _slaveID;
    modbusMaster modbus;
};

#endif
