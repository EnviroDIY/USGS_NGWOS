# Scanning Registers<!--! {#example_scan_registers} -->

This is a testing program to scan through all possible holding registers.
This was written to try to guess the structure of the modbus registers when a map isn't available.

_______


<!--! @section example_scan_registers_pio_config PlatformIO Configuration -->

<!--! @include{lineno} scanRegisters/platformio.ini -->

<!--! @section example_scan_registers_code The Complete Code -->

<!--! @include{lineno} scanRegisters/scanRegisters.ino -->
