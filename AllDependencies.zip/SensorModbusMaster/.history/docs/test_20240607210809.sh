# only continue if these steps fail
# doing this here to print the Doxygen log if it fails
set +e

echo "\n\e[32mGenerating Doxygen code documentation...\e[0m"
echo "::group::Doxygen Run Log"
# Redirect both stderr and stdout to the log file AND the console.
doxygen Doxyfile 2>&1 | tee output_doxygen_run.log
result_code=${PIPESTATUS[0]}
echo "::endgroup::"
echo "::group::Doxygen Output"
echo "$(<output_doxygen.log)"
echo "::endgroup::"
if [[ "$result_code" -ne "0" ]]; then exit "$result_code"; else echo "Doxygen succeeded!"; fi
