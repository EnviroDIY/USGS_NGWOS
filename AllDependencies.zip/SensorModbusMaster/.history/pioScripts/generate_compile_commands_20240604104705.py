import os

Import("env")

print(COMMAND_LINE_TARGETS)
if "compiledb" not in COMMAND_LINE_TARGETS:
    # env.Exit(0)
    COMMAND_LINE_TARGETS.extend(["compiledb"])
print(COMMAND_LINE_TARGETS)

print("Generating compile commands!")

# include toolchain paths
env.Replace(COMPILATIONDB_INCLUDE_TOOLCHAIN=True)
print(env["COMPILATIONDB_INCLUDE_TOOLCHAIN"])

# override compilation DB path
env.Replace(
    COMPILATIONDB_PATH=os.path.join("$PROJECT_DIR/.vscode", "compile_commands.json")
)
print(env["COMPILATIONDB_PATH"])
