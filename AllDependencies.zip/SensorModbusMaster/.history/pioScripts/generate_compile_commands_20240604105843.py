import os
import sys

Import("env")

if "compiledb" not in COMMAND_LINE_TARGETS:
   sys.exit()

print("Generating compile commands!")

# include toolchain paths
env.Replace(COMPILATIONDB_INCLUDE_TOOLCHAIN=True)

# override compilation DB path
# print(env["COMPILATIONDB_PATH"])
env.Replace(
    COMPILATIONDB_PATH=os.path.join("$PROJECT_DIR/.vscode", "compile_commands.json")
)
# print(env["COMPILATIONDB_PATH"])
