| ID    | Variable                     | Application                                              |
| ----- | ---------------------------- | -------------------------------------------------------- |
| **U** | TurnerCyclops_CDOM           | CDOM/FDOM                                                |
| **C** | TurnerCyclops_Chlorophyll    | Chl in vivo (Blue Excitation)                            |
| **D** | TurnerCyclops_RedChlorophyll | Chl in vivo (Red Excitation)                             |
| **F** | TurnerCyclops_Fluorescein    | Fluorescein Dye                                          |
| **O** | TurnerCyclops_CrudeOil       | Oil - Crude                                              |
| **G** | TurnerCyclops_BTEX           | Oil - Fine (Refined Fuels)                               |
| **B** | TurnerCyclops_Brighteners    | Optical Brighteners for Wastewater Monitoring            |
| **P** | TurnerCyclops_Phycocyanin    | Phycocyanin (Freshwater Cyanobacteria)                   |
| **E** | TurnerCyclops_Phycoerythrin  | Phycoerythrin (Marine Cyanobacteria)                     |
| **A** | TurnerCyclops_PTSA           | PTSA (1,3,6,8-Pyrenetetrasulfonic Acid Tetrasodium Salt) |
| **R** | TurnerCyclops_Rhodamine      | Rhodamine Dye                                            |
| **L** | TurnerCyclops_Tryptophan     | Tryptophan for Wastewater Monitoring                     |
| **T** | TurnerCyclops_Turbidity      | Turbidity                                                |

| ID    | MDL       | Linear Range | LED (CWL) | Excitation | Emission   | Power @ 12V |
| ----- | --------- | ------------ | --------- | ---------- | ---------- | ----------- |
| **U** | 0.1 ppb¹  | 0-1,500 ppb¹ | 365 nm    | 325/120 nm | 470/60 nm  | 240 mW      |
|       | 0.5 ppb²  | 0-3,000 ppb² | 365 nm    | 325/120 nm | 470/60 nm  |             |
| **C** | 0.03 μg/L | 0-500 μg/L   | 460 nm    | 465/170 nm | 696/44 nm  | 240 mW      |
| **D** | 0.3 μg/L  | 0-500 μg/L   | 635 nm    | ≤ 635 nm   | > 695 nm   | 240         |
| **F** | 0.01 ppb  | 0-500 ppb    | 460 nm    | 400/150 nm | 545/28 nm  | 145 mW      |
| **O** | 0.2 ppb²  | 0-1,500 ppb² | 365 nm    | 325/120 nm | 410-600 nm | 250 mW      |
| **G** | 0.4ppm³   | 0-20 ppm³    | 255 nm    | ≤ 290 nm   | 350/50 nm  | 530 mW      |
| **B** | 0.6 ppb²  | 0-2,500 ppb² | 365 nm    | 325/120 nm | 445/15 nm  | 200 mW      |
| **P** | 2 ppb⁴    | 0-4,500 ppb⁴ | 590 nm    | 590/30 nm  | ≥ 645 nm   | 160 mW      |
| **E** | 0.1 ppb⁵  | 0-750 ppb⁵   | 525 nm    | 515-547 nm | ≥ 590 nm   | 270 mW      |
| **A** | 0.1 ppb²  | 0-650 ppb²   | 365 nm    | 325/120 nm | 405/10 nm  | 320 mW      |
| **R** | 0.01 ppb  | 0-1,000 ppb  | 530 nm    | 535/60 nm  | 590-715 nm | 175 mW      |
| **L** | 3 ppb     | 0-5,000 ppb  | 275 nm    | -          | 350/55 nm  | 540 mW      |
| **T** | 0.05 NTU  | 0-1,500 NTU  | 850 nm    | 850 nm     | 850 nm     | 120 mW      |


| ID  | Variable                                             | Units                               |
| --- | ---------------------------------------------------- | ----------------------------------- |
| C   | TurnerCyclops_Chlorophyll                            | micrograms per Liter (µg/L)         |
| R   | TurnerCyclops_Rhodamine      Parts per billion (ppb) |
| F   | TurnerCyclops_Fluorescein    Parts per billion (ppb) |
| P   | TurnerCyclops_Phycocyanin    Parts per billion (ppb) |
| E   | TurnerCyclops_Phycoerythrin  Parts per billion (ppb) |
| U   | TurnerCyclops_CDOM           Parts per billion (ppb) |
| O   | TurnerCyclops_CrudeOil       Parts per billion (ppb) |
| B   | TurnerCyclops_Brighteners    Parts per billion (ppb) |
| T   | TurnerCyclops_Turbidity                              | nephelometric turbidity units (NTU) |
| A   | TurnerCyclops_PTSA           Parts per billion (ppb) |
| G   | TurnerCyclops_BTEX           Parts per million (ppm) |
| L   | TurnerCyclops_Tryptophan     Parts per billion (ppb) |
| D   | TurnerCyclops_RedChlorophyll                         | micrograms per Liter (µg/L)         |


Table 10: Recommended filter settings based on use cases
|                 Use case                 |  Mode  | Over-sampling setting | Pressure over-sampling | Temperature over-sampling | IIR filter coefficient | Standby Time (ms) | Output Data Rate (ODR) [Hz] | Current Consumption (I<sub>DD</sub>) [μA] | RMS Noise [cm] |
| :--------------------------------------: | :----: | :-------------------: | :--------------------: | :-----------------------: | :--------------------: | :---------------: | :-------------------------: | :---------------------------------------: | :------------: |
| handheld device low-power (e.g. Android) | Normal |    High resolution    |           x8           |            x1             |           2            |        80         |            12.5             |                    145                    |       11       |
|  handheld device dynamic (e.g. Android)  | Normal |  Standard resolution  |           x4           |            x1             |           4            |        20         |             50              |                    310                    |       10       |
|    Weather monitoring (lowest power)     | Forced |    Ultra low power    |           x1           |            x1             |          Off           |       N/A¹        |            1/60             |                     4                     |       55       |
|              Drop detection              | Normal |       Low power       |           x2           |            x1             |          Off           |        10         |             100             |                    358                    |       36       |
|            Indoor navigation             | Normal | Ultra high resolution |          x16           |            x2             |           4            |        40         |             25              |                    560                    |       5        |
|                  Drone                   | Normal |  Standard resolution  |           x8           |            x1             |           2            |        20         |             50              |                    570                    |       11       |
|           Indoor localization            | Normal |    Ultra low power    |           x1           |            x1             |           4            |        640        |              1              |                     -                     |       -        |
¹ Standby time doesn't apply in forced mode

| Oversampling setting  | Pressure oversampling | Typical pressure resolution | Recommended temperature oversampling | Measurement Time (typ., µsec) |
| :-------------------: | :-------------------: | :-------------------------: | :----------------------------------: | :---------------------------: |
|    Ultra low power    |          ×1           |      16 bit / 2.64 Pa       |                  ×1                  |             6849              |
|       Low power       |          ×2           |      17 bit / 1.32 Pa       |                  ×1                  |             8869              |
|  Standard resolution  |          ×4           |      18 bit / 0.66 Pa       |                  ×1                  |             12909             |
|    High resolution    |          ×8           |      19 bit / 0.33 Pa       |                  ×1                  |             20989             |
| Ultra high resolution |          ×16          |      20 bit / 0.17 Pa       |                  ×2                  |             41189             |
|  Highest resolution   |          ×32          |      21 bit / 0.085 Pa      |                  ×2                  |             73509             |