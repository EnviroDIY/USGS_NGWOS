/**
 * @file ThingSpeakPublisher.h
 * @copyright Stroud Water Research Center
 * Part of the EnviroDIY ModularSensors library for Arduino.
 * This library is published under the BSD-3 license.
 * @author Sara Geleskie Damiano <sdamiano@stroudcenter.org>
 *
 * @brief Contains the ThingSpeakPublisher subclass of dataPublisher for
 * publishing data to ThingSpeak using the MQTT protocol.
 */

// Header Guards
#ifndef SRC_PUBLISHERS_THINGSPEAKPUBLISHER_H_
#define SRC_PUBLISHERS_THINGSPEAKPUBLISHER_H_

// Include the library config before anything else
#include "ModSensorConfig.h"

// Include the debugging config
#include "ModSensorDebugConfig.h"

// Define the print label[s] for the debugger
#ifdef MS_THINGSPEAKPUBLISHER_DEBUG
#define MS_DEBUGGING_STD "ThingSpeakPublisher"
#endif

// Include the debugger
#include "ModSensorDebugger.h"
// Undefine the debugger label[s]
#undef MS_DEBUGGING_STD

// Include other in-library and external dependencies
#include "dataPublisherBase.h"
#include "PubSubClient.h"


// ============================================================================
//  Functions for ThingSpeak.
// ============================================================================
/**
 * @brief The ThingSpeakPublisher subclass of dataPublisher for publishing data
 * to ThingSpeak using the MQTT protocol.
 *
 * When sending data to ThingSpeak the order of the variables in the variable
 * array attached to your logger is __crucial__.  The results from the variables
 * in the VariableArray will be sent to ThingSpeak in the order they are in the
 * array; that is, the first variable in the array will be sent as Field1, the
 * second as Field2, etc.  Any UUID's or custom variable codes are ignored for
 * ThingSpeak.  They will only appear in the header of your file on the SD card.
 * Giving a variable a custom variable code like "Field3" will **NOT** make that
 * variable field 3 on ThingSpeak.  The third variable in the array will always
 * be "Field3".  Any text names you have given to your fields in ThingSpeak are
 * also irrelevant.
 *
 * @ingroup the_publishers
 */
class ThingSpeakPublisher : public dataPublisher {
 public:
    // Constructors
    /**
     * @brief Construct a new ThingSpeak Publisher object with no members
     * initialized.
     */
    ThingSpeakPublisher();
    /**
     * @brief Construct a new ThingSpeak Publisher object
     *
     * @note If a client is never specified, the publisher will attempt to
     * create and use a client on a LoggerModem instance tied to the attached
     * logger.
     *
     * @param baseLogger The logger supplying the data to be published
     * @param sendEveryX Interval (in units of the logging interval) between
     * attempted data transmissions. NOTE: not implemented by this publisher!
     */
    explicit ThingSpeakPublisher(Logger& baseLogger, int sendEveryX = 1);
    /**
     * @brief Construct a new ThingSpeak Publisher object
     *
     * @param baseLogger The logger supplying the data to be published
     * @param inClient An Arduino client instance to use to print data to.
     * Allows the use of any type of client and multiple clients tied to a
     * single TinyGSM modem instance
     * @param sendEveryX Interval (in units of the logging interval) between
     * attempted data transmissions. NOTE: not implemented by this publisher!
     */
    ThingSpeakPublisher(Logger& baseLogger, Client* inClient,
                        int sendEveryX = 1);
    /**
     * @brief Construct a new ThingSpeak Publisher object
     *
     * @param baseLogger The logger supplying the data to be published
     * @param thingSpeakClientName The client name for your MQTT device. This is
     * probably the same as your MQTT device's user name.
     * @param thingSpeakMQTTUser The user name for your MQTT device. This is
     * probably the same as your MQTT device's client name.
     * @param thingSpeakMQTTPassword The password for your MQTT device.
     * @param thingSpeakChannelID The numeric channel id for your channel.
     * @param sendEveryX Interval (in units of the logging interval) between
     * attempted data transmissions. NOTE: not implemented by this publisher!
     */
    ThingSpeakPublisher(Logger& baseLogger, const char* thingSpeakClientName,
                        const char* thingSpeakMQTTUser,
                        const char* thingSpeakMQTTPassword,
                        const char* thingSpeakChannelID, int sendEveryX = 1);
    /**
     * @brief Construct a new ThingSpeak Publisher object
     *
     * @param baseLogger The logger supplying the data to be published
     * @param inClient An Arduino client instance to use to print data to.
     * Allows the use of any type of client and multiple clients tied to a
     * single TinyGSM modem instance
     * @param thingSpeakClientName The client name for your MQTT device. This is
     * probably the same as your MQTT device's user name.
     * @param thingSpeakMQTTUser The user name for your MQTT device. This is
     * probably the same as your MQTT device's client name.
     * @param thingSpeakMQTTPassword The password for your MQTT device.
     * @param thingSpeakChannelID The numeric channel id for your channel.
     * @param sendEveryX Interval (in units of the logging interval) between
     * attempted data transmissions. NOTE: not implemented by this publisher!
     */
    ThingSpeakPublisher(Logger& baseLogger, Client* inClient,
                        const char* thingSpeakClientName,
                        const char* thingSpeakMQTTUser,
                        const char* thingSpeakMQTTPassword,
                        const char* thingSpeakChannelID, int sendEveryX = 1);
    /**
     * @brief Destroy the ThingSpeak Publisher object
     */
    virtual ~ThingSpeakPublisher();

    // Returns the data destination
    String getEndpoint(void) override {
        return String(mqttServer);
    }

    /**
     * @brief The client name for your MQTT device. This is probably the same as
     * your MQTT device's user name.
     *
     * @param thingSpeakClientName The client name for your MQTT device. This is
     * probably the same as your MQTT device's user name.
     */
    void setMQTTClient(const char* thingSpeakClientName);

    /**
     * @brief Set the user name for your MQTT device.
     *
     * @param thingSpeakMQTTUser The user name for your MQTT device. This is
     * probably the same as your MQTT device's client name.
     */
    void setUserName(const char* thingSpeakMQTTUser);

    /**
     * @brief Set the password for your MQTT device.
     *
     * @param thingSpeakMQTTPassword The password for your MQTT device.
     */
    void setPassword(const char* thingSpeakMQTTPassword);

    /**
     * @brief Set the ThingSpeak channel ID
     *
     * @param thingSpeakChannelID The numeric channel id for your channel
     */
    void setChannelID(const char* thingSpeakChannelID);

    /**
     * @brief Set the ThingSpeak user REST API key
     *
     * This is only used to update the field names on the ThingSpeak channel
     * during the updateMetadata call at boot up. The *user* REST API key is
     * **NOT** the same as your *channel* API keys or your MQTT connection
     * credentials.  Find this key in your ThingSpeak account under Account > My
     * Profile.
     *
     * @param thingSpeakAPIKey The ThingSpeak user REST API key
     */
    void setRESTAPIKey(const char* thingSpeakAPIKey);

    /**
     * @brief Sets all 4 ThingSpeak parameters
     *
     * @param thingSpeakClientName The client name for your MQTT device. This is
     * probably the same as your MQTT device's user name.
     * @param thingSpeakMQTTUser The user name for your MQTT device. This is
     * probably the same as your MQTT device's client name.
     * @param thingSpeakMQTTPassword The password for your MQTT device.
     * @param thingSpeakChannelID The numeric channel id for your channel.
     */
    void setThingSpeakParams(const char* thingSpeakClientName,
                             const char* thingSpeakMQTTUser,
                             const char* thingSpeakMQTTPassword,
                             const char* thingSpeakChannelID);

    /**
     * @copydoc dataPublisher::begin(Logger& baseLogger, Client* inClient)
     * @param thingSpeakClientName The client name for your MQTT device. This is
     * probably the same as your MQTT device's user name.
     * @param thingSpeakMQTTUser The user name for your MQTT device. This is
     * probably the same as your MQTT device's client name.
     * @param thingSpeakMQTTPassword The password for your MQTT device.
     * @param thingSpeakChannelID The numeric channel id for your channel.
     */
    void begin(Logger& baseLogger, Client* inClient,
               const char* thingSpeakClientName, const char* thingSpeakMQTTUser,
               const char* thingSpeakMQTTPassword,
               const char* thingSpeakChannelID);
    /**
     * @copydoc dataPublisher::begin(Logger& baseLogger)
     * @param thingSpeakClientName The client name for your MQTT device. This is
     * probably the same as your MQTT device's user name.
     * @param thingSpeakMQTTUser The user name for your MQTT device. This is
     * probably the same as your MQTT device's client name.
     * @param thingSpeakMQTTPassword The password for your MQTT device.
     * @param thingSpeakChannelID The numeric channel id for your channel.
     */
    void begin(Logger& baseLogger, const char* thingSpeakClientName,
               const char* thingSpeakMQTTUser,
               const char* thingSpeakMQTTPassword,
               const char* thingSpeakChannelID);

    /**
     * @brief Utilize an attached modem to open a TCP connection to ThingSpeak
     * and publish data over that connection.
     *
     * This depends on an internet connection already having been made and a
     * client being available.
     *
     * @param outClient An Arduino client instance to use to print data to.
     * Allows the use of any type of client and multiple clients tied to a
     * single TinyGSM modem instance
     * @param forceFlush Ask the publisher to flush buffered data immediately.
     * @return The PubSubClient status code of the response.
     */
    int16_t publishData(Client* outClient,
                        bool forceFlush = MS_ALWAYS_FLUSH_PUBLISHERS) override;
    int16_t publishMetadata(Client* outClient) override;

 protected:
    /**
     * @anchor ts_mqqt_vars
     * @name Portions of the MQTT data publication
     *
     * @{
     */
    static const char* apiHost;  ///< The REST API host
    static const int   apiPort;  ///< The REST API port
    static const char*
        channelMetaResource;  ///< The REST API resource to put metadata to
    static const char* mqttServer;  ///< The MQTT server
    static const int   mqttPort;    ///< The MQTT port
                                    /**@}*/

 private:
    // Keys for ThingSpeak
    /**
     * @brief The client name for your MQTT device. This is probably the same as
     * your MQTT device's user name.
     */
    const char* _thingSpeakClientName = nullptr;
    /**
     * @brief The user name for your MQTT device. This is probably the same as
     * your MQTT device's client name.
     */
    const char* _thingSpeakMQTTUser = nullptr;
    /**
     * @brief The password for your MQTT device
     */
    const char* _thingSpeakMQTTPassword = nullptr;
    /**
     * @brief The channel ID for ThingSpeak
     */
    const char* _thingSpeakChannelID = nullptr;
    /**
     * @brief The ThingSpeak REST API key
     */
    const char* _thingSpeakAPIKey = nullptr;
    /**
     * @brief Internal reference to the PubSubClient instance for MQTT
     * communication.
     */
    PubSubClient _mqttClient;
};

#endif  // SRC_PUBLISHERS_THINGSPEAKPUBLISHER_H_
