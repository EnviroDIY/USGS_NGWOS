

MS_DEEP_DBG(F("Counting the number of unique power pins:"));
int nUniquePPs = 1;
// Pick all elements one by one
for (int i = 1; i < _sensorCount * 2; i++) {
    int j = 0;
    for (j = 0; j < i; j++) {
        if (powerPins[i] == powerPins[j]) break;
    }
    // If not printed earlier, then print it
    if (i == j) nUniquePPs++;
}
MS_DEEP_DBG(nUniquePPs);

MS_DBG(F("Reducing the array to the unique power pins.."));
// create the array - if every sensor has two unique pins, this array could
// be twice the number of sensors
int8_t uniquePowerPins[_sensorCount * 2];
int8_t totalPowerPinMeasurements[_sensorCount * 2];
// initialize with -1s
for (uint8_t i = 0; i < _sensorCount * 2; i++) { uniquePowerPins[i] = -1; }
for (uint8_t i = 0; i < _sensorCount * 2; i++) {
    totalPowerPinMeasurements[i] = 0;
}
uint8_t nPowerPins = 0;
for (uint8_t i = 0; i < _sensorCount * 2; i++) {
    // If current element is not equal to next element then store that
    // current element
    if (uniquePowerPins[i] != uniquePowerPins[i + 1] &&
        uniquePowerPins[i] >= 0) {
        nPowerPins++;
        uniquePowerPins[nPowerPins] = uniquePowerPins[i];
        totalPowerPinMeasurements[nPowerPins] += uniquePowerPins[i];
    }
    // Store the last element as whether it is unique or repeated, it hasn't
    // stored previously
    uniquePowerPins[nPowerPins++] = uniquePowerPins[_sensorCount * 2 - 1];
}
delay(100);
MS_DEEP_DBG(F("Number of unique pins:"), nPowerPins);
MS_DEEP_DBG(F("uniquePowerPins:\t\t\t"));
prettyPrintArray(uniquePowerPins, _sensorCount * 2);
delay(100);


// Create an array to tell us how many measurements must be taken on each
// unique power pin
uint8_t nMeasurementsOnPin[nPowerPins];
for (uint8_t i = 0; i < _sensorCount; i++) {
    int8_t primaryPin   = sensorList[i]->getPowerPin();
    int8_t secondaryPin = sensorList[i]->getSecondaryPowerPin();
    for (uint8_t i = 0; i < nPowerPins; i++) {
        if (primaryPin == uniquePowerPins[i]) {
            nMeasurementsOnPin[i] +=
                sensorList[i]->getNumberMeasurementsToAverage();
        }
        if (secondaryPin == uniquePowerPins[i]) {
            nMeasurementsOnPin[i] +=
                sensorList[i]->getNumberMeasurementsToAverage();
        }
    }
}
delay(100);
MS_DEEP_DBG(F("nMeasurementsOnPin:\t\t\t"));
prettyPrintArray(nMeasurementsOnPin, nPowerPins);
delay(100);
