
    // USB->HOST.CTRLA.bit.ENABLE = 0;         // Disable the USB peripheral
    // while (USB->HOST.SYNCBUSY.bit.ENABLE);  // Wait for synchronization
    // USB->HOST.CTRLA.bit.RUNSTDBY = 0;       // Deactivate run on standby
    // USB->HOST.CTRLA.bit.ENABLE   = 1;       // Enable the USB peripheral
    // while (USB->HOST.SYNCBUSY.bit.ENABLE);  // Wait for synchronization
