

// from circuit python, common_hal_mcu_disable_interrupts is called before
// entering sleep:
// https://github.com/adafruit/circuitpython/blob/65cfcb83f279869c7b38eb5891ddac557dba155b/ports/atmel-samd/supervisor/port.c#L678
// https://github.com/adafruit/circuitpython/blob/65cfcb83f279869c7b38eb5891ddac557dba155b/ports/atmel-samd/common-hal/microcontroller/__init__.c#L25
// __disable_irq();
// __DMB();  // data memory barrier

__DSB();  // Data sync barrier - to ensure outgoing memory accesses
          // complete
__WFI();  // wait for interrupt
          // https://stackoverflow.com/questions/46934649/arm-wfi-wont-sleep
// There are three conditions that cause the processor to wake up from a WFI
// instruction:
// - a non-masked interrupt occurs and its priority is greater than the
// current execution priority (i.e. the interrupt is taken)
// - an interrupt masked by PRIMASK becomes pending
// - a Debug Entry request.
// For tips on failing to sleep, see:
// https://www.eevblog.com/forum/microcontrollers/crashing-through-__wfi/

// from circuit python, common_hal_mcu_enable_interrupts is called after
// leaving sleep:
// https://github.com/adafruit/circuitpython/blob/65cfcb83f279869c7b38eb5891ddac557dba155b/ports/atmel-samd/common-hal/microcontroller/__init__.c#L31
// __DMB();  // data memory barrier
// __enable_irq();
