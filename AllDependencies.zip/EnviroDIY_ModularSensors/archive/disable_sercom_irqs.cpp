
#if defined(__SAMD51__)

IRQn_Type sercom_irqs[] = {
    SERCOM0_0_IRQn, SERCOM0_1_IRQn, SERCOM0_2_IRQn, SERCOM0_3_IRQn,
    SERCOM1_0_IRQn, SERCOM1_1_IRQn, SERCOM1_2_IRQn, SERCOM1_3_IRQn,
    SERCOM2_0_IRQn, SERCOM2_1_IRQn, SERCOM2_2_IRQn, SERCOM2_3_IRQn,
    SERCOM3_0_IRQn, SERCOM3_1_IRQn, SERCOM3_2_IRQn, SERCOM3_3_IRQn,
    SERCOM4_0_IRQn, SERCOM4_1_IRQn, SERCOM4_2_IRQn, SERCOM4_3_IRQn,
    SERCOM5_0_IRQn, SERCOM5_1_IRQn, SERCOM5_2_IRQn, SERCOM5_3_IRQn,
#if defined(SERCOM6)
    SERCOM6_0_IRQn, SERCOM6_1_IRQn, SERCOM6_2_IRQn, SERCOM6_3_IRQn,
#endif  // SERCOM6
#if defined(SERCOM7)
    SERCOM7_0_IRQn, SERCOM7_1_IRQn, SERCOM7_2_IRQn, SERCOM7_3_IRQn,
#endif  // SERCOM7
};
bool sercom_irqs_enabled[] = {
    false, false, false, false, false, false, false, false,
    false, false, false, false, false, false, false, false,
    false, false, false, false, false, false, false, false,
#if defined(SERCOM6)
    false, false, false, false,
#endif  // SERCOM6
#if defined(SERCOM7)
    false, false, false, false,
#endif  // SERCOM7
};
#else  // SAMD21
IRQn_Type sercom_irqs[] = {
    SERCOM0_IRQn, SERCOM1_IRQn, SERCOM2_IRQn, SERCOM3_IRQn,
#if defined(SERCOM4)
    SERCOM4_IRQn,
#endif  // SERCOM4
#if defined(SERCOM5)
    SERCOM5_IRQn,
#endif  // SERCOM5
};
bool sercom_irqs_enabled[] = {
    false, false, false, false,
#if defined(SERCOM4)
    false,
#endif  // SERCOM4
#if defined(SERCOM5)
    false,
};
#endif  // SERCOM5
#endif  // SAMD51

// disable all SERCOM interrupts
for (uint8_t i = 0; i < (sizeof(sercom_irqs) / sizeof(sercom_irqs[0])); i++) {
    if (NVIC_GetEnableIRQ((IRQn_Type)(sercom_irqs[i]))) {  // If enabled
        sercom_irqs_enabled[i] = true;  // remember that it was enabled
        NVIC_DisableIRQ((IRQn_Type)(sercom_irqs[i]));       // Disable
        NVIC_ClearPendingIRQ((IRQn_Type)(sercom_irqs[i]));  // Clear old flags
    }
}


#if defined(__SAMD51__)
// re-enable the SERCOM interrupts that were disabled before sleep
for (uint8_t i = 0; i < (sizeof(sercom_irqs) / sizeof(sercom_irqs[0])); i++) {
    if (sercom_irqs_enabled[i]) {                     // If previously enabled
        NVIC_EnableIRQ((IRQn_Type)(sercom_irqs[i]));  // enable
    }
}
delay(50);
#endif
