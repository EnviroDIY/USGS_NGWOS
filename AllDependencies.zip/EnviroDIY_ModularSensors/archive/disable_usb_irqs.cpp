

#if defined(__SAMD51__)
MS_DEEP_DBG(F("Disabling all USB NVIC interrupts"));
IRQn_Type usb_irqs[] = {(IRQn_Type)(80), (IRQn_Type)(81), (IRQn_Type)(82),
                        (IRQn_Type)(83)};
// disable all USB interrupts
for (uint8_t i = 0; i < (sizeof(usb_irqs) / sizeof(usb_irqs[0])); i++) {
    NVIC_DisableIRQ((IRQn_Type)(usb_irqs[i]));       // Disable
    NVIC_ClearPendingIRQ((IRQn_Type)(usb_irqs[i]));  // Clear old flags
}
#endif  // SAMD51


#if defined(__SAMD51__)
// re-enable the USB interrupts that were disabled before sleep
for (uint8_t i = 0; i < (sizeof(usb_irqs) / sizeof(usb_irqs[0])); i++) {
    NVIC_EnableIRQ((IRQn_Type)(usb_irqs[i]));  // enable
}
delay(50);
#endif
