

#if defined(__SAMD51__)
MS_DBG(F("Disabling the DMAC on standby"));
// Disable the DMAC in standby
// This is needed to prevent the DMAC from waking up the processor
for (uint8_t i = 0; i < DMAC_CH_NUM; i++) {
    PRINTOUT(F("DMAC channel"), i, F("on standby:"),
             DMAC->Channel[i].CHCTRLA.bit.RUNSTDBY);
    DMAC->Channel[i].CHCTRLA.bit.RUNSTDBY = 0;
}
#endif
