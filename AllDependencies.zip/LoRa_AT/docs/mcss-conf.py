DOXYFILE = "mcss-Doxyfile"
THEME_COLOR = "#cb4b16"
LINKS_NAVBAR1 = []
LINKS_NAVBAR2 = []
VERSION_LABELS = True
CLASS_INDEX_EXPAND_LEVELS = 2

STYLESHEETS = [
    "css/m-EnviroDIY+documentation.compiled.css",
]
