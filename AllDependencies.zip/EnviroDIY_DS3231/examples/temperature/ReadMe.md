This example sends the current chip temperature in Celsius to the serial port every second at 57600 baud.
